package com.example.adskiphelper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;

/**
 * Ищет на экране кнопки «Пропустить» / «Закрыть» у рекламы и нажимает их.
 *
 * 1) Кнопка с подписью (текст / описание / id) — нажимаем.
 *    Подпись про рекламу ("Пропустить рекламу", "Close ad") — нажимаем всегда,
 *    общие ("Закрыть", "Skip", "×") — только если на экране есть метка «Реклама».
 * 2) Кнопка без подписи (иконка ✕ или ▶| в правом верхнем углу): если на экране
 *    есть метка «Реклама» и в углу ровно ОДНА маленькая иконка — нажимаем её.
 * Кнопки «Скачать», «Установить», «Забрать бонус» и т.п. не нажимаются никогда.
 */
public class AdSkipAccessibilityService extends AccessibilityService {
    private long lastClick = 0L;

    // состояние одного прохода по дереву
    private boolean adMarker;
    private AccessibilityNodeInfo labeled;
    private int labeledLevel;
    private AccessibilityNodeInfo corner;
    private int cornerCount;
    private int screenW, screenH, maxIcon;

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (SystemClock.uptimeMillis() - lastClick < 1200) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        float density = getResources().getDisplayMetrics().density;
        screenW = getResources().getDisplayMetrics().widthPixels;
        screenH = getResources().getDisplayMetrics().heightPixels;
        maxIcon = (int) (80 * density);

        adMarker = false;
        labeled = null;
        labeledLevel = 0;
        corner = null;
        cornerCount = 0;

        scan(root, 0);

        AccessibilityNodeInfo target = null;
        if (labeled != null && (labeledLevel == 2 || adMarker)) {
            target = labeled;
        } else if (adMarker && corner != null && cornerCount == 1) {
            target = corner;
        }

        if (target != null && click(target, density)) {
            lastClick = SystemClock.uptimeMillis();
        }
    }

    private void scan(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 40 || !n.isVisibleToUser()) return;

        String text = lower(n.getText());
        String desc = lower(n.getContentDescription());
        String id = lower(n.getViewIdResourceName());

        if (isAdMarker(text) || isAdMarker(desc)) adMarker = true;

        if (!isBlocked(text) && !isBlocked(desc)) {
            int level = Math.max(matchLevel(text), Math.max(matchLevel(desc), matchLevel(id)));
            if (level > labeledLevel) {
                labeled = n;
                labeledLevel = level;
            }

            // иконка без подписи в правом верхнем углу
            if ((n.getChildCount() == 0 || n.isClickable()) && text.length() <= 1) {
                Rect r = new Rect();
                n.getBoundsInScreen(r);
                if (r.width() > 0 && r.height() > 0
                        && r.width() <= maxIcon && r.height() <= maxIcon
                        && r.centerY() < screenH * 0.15f
                        && r.centerX() > screenW * 0.6f) {
                    corner = n;
                    cornerCount++;
                }
            }
        }

        for (int i = 0; i < n.getChildCount(); i++) {
            scan(n.getChild(i), depth + 1);
        }
    }

    /** 0 — не подходит, 1 — общая кнопка закрытия, 2 — явно про рекламу. */
    private int matchLevel(String s) {
        if (s.isEmpty()) return 0;
        boolean closeWord = s.contains("skip") || s.contains("close") || s.contains("dismiss")
                || s.contains("пропуст") || s.contains("закры") || s.contains("закрыт");
        if (closeWord) {
            String p = " " + s.replace('_', ' ').replace('.', ' ').replace(':', ' ')
                    .replace('-', ' ').replace('/', ' ') + " ";
            boolean adWord = p.contains("реклам") || p.contains(" ad ") || p.contains(" ads ")
                    || p.contains("advert");
            return adWord ? 2 : 1;
        }
        if (s.equals("×") || s.equals("✕") || s.equals("✖") || s.equals("✗") || s.equals("x")) return 1;
        return 0;
    }

    private boolean isAdMarker(String s) {
        if (s.isEmpty()) return false;
        return s.startsWith("реклама") || s.equals("ad") || s.equals("ads")
                || s.equals("sponsored") || s.equals("advertisement") || s.startsWith("ad ·");
    }

    /** Кнопки, которые нажимать нельзя. */
    private boolean isBlocked(String s) {
        if (s.isEmpty()) return false;
        String[] bad = {
            "скачать", "download", "install", "установ", "купить", "buy", "открыть", "open",
            "перейти", "подробнее", "learn more", "забрать", "играть", "play", "узнать",
            "бонус", "bonus", "получить", "регистрац", "sign up", "register", "shop"
        };
        for (String b : bad) if (s.contains(b)) return true;
        return false;
    }

    private boolean click(AccessibilityNodeInfo n, float density) {
        int limit = (int) (120 * density);
        AccessibilityNodeInfo t = n;
        for (int d = 0; t != null && d < 5; d++) {
            if (t.isClickable()) {
                Rect r = new Rect();
                t.getBoundsInScreen(r);
                // слишком большой кликабельный контейнер — это может быть сам баннер
                if (r.width() <= limit && r.height() <= limit) {
                    return t.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                }
                break;
            }
            t = t.getParent();
        }
        // иконка не помечена как кликабельная — нажимаем жестом в её центр
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        Path p = new Path();
        p.moveTo(r.exactCenterX(), r.exactCenterY());
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 50))
                .build();
        return dispatchGesture(g, null, null);
    }

    private String lower(CharSequence s) {
        return s == null ? "" : s.toString().toLowerCase(Locale.ROOT).trim();
    }

    @Override public void onInterrupt() {}
}
